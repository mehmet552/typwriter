#!/bin/bash
set -e

PREFIX="${PREFIX:-$HOME/.local}"
rm -f "$PREFIX/bin/typwriter"
rm -f "$PREFIX/share/applications/com.github.mehmet.typwriter.desktop"
rm -f "$PREFIX/share/icons/hicolor/scalable/apps/com.github.mehmet.typwriter.svg"

echo "✅ Typwriter başarıyla kaldırıldı."
