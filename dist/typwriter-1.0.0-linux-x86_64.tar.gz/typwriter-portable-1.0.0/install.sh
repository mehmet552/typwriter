#!/bin/bash
set -e

echo "🖋️ Typwriter Taşınabilir Kurulum / Portable Installation"
echo "========================================================"

PREFIX="${PREFIX:-$HOME/.local}"
echo "Kurulum konumu: $PREFIX"

mkdir -p "$PREFIX/bin"
mkdir -p "$PREFIX/share/applications"
mkdir -p "$PREFIX/share/icons/hicolor/scalable/apps"

install -m755 typwriter "$PREFIX/bin/typwriter"
install -m644 com.github.mehmet.typwriter.desktop "$PREFIX/share/applications/"
install -m644 com.github.mehmet.typwriter.svg "$PREFIX/share/icons/hicolor/scalable/apps/"

if command -v update-desktop-database &> /dev/null; then
    update-desktop-database "$PREFIX/share/applications" 2>/dev/null || true
fi

echo "✅ Kurulum başarıyla tamamlandı!"
echo "Uygulama menüsünden veya '$PREFIX/bin/typwriter' komutuyla başlatabilirsiniz."
